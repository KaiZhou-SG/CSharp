﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace frmScheduler00.BLL
{
    /// <summary>
    /// 
    /// </summary>
    internal class VehicleAvailability
    {
    }
}
